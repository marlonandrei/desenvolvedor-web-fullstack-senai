<!DOCTYPE html>
<html>
<body>

<script>

alert("Olá, mundo...");

var nome = prompt('Nome: ')
var datanasc = prompt('Data Nascimento: ')
var idade = prompt('Idade: ')
var telefone = prompt('Telefone: ')
var cpf = prompt('CPF: ')
var rg = prompt('RG: ')
var endereco = prompt('Endereço: ')
var email = prompt('E-mail: ')
var telefone = prompt('Telefone: ')
var sexo = prompt('Sexo: ')
var salario = prompt('Salário: ')
var ativo = prompt('Ativo: ')

var ir = salario * 0.15
alert('Olá ' +  nome + ', o valor do seu Imposto de Renda será: ' + ir)

</script>

</body>
</html>
