print("Olá, mundo...")

nome = input('Nome: ')
datanasc = input('Data Nascimento: ')
idade = input('Idade: ')
telefone = input('Telefone: ')
cpf = input('CPF: ')
rg = input('RG: ')
endereco = input('Endereço: ')
email = input('E-mail: ')
telefone = input('Telefone: ')
sexo = input('Sexo: ')
salario = float(input('Salário: '))
ativo = input('Ativo: ')

ir = salario * 0.15
print('')
print('Olá ', nome, ', o valor do seu Imposto de Renda será: ', ir)